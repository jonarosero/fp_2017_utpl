import pilasengine
pilas = pilasengine.iniciar()

def entrada():
    pilas.escenas.Normal()
    pilas.fondos.Galaxia()
    pilas.actores.Menu( [ ( " Iniciar Juego" , iniciar_juego ) , ( " Instrucciones " , instrucciones_juego ) ,("Opciones",opciones_juego), ( " Salir " , salida ) , ] )
    cartel = pilas.actores.Nave()
    cartel.escala = 2
    cartel.x = -2
    cartel.y = 132

def iniciar_juego():
    pilas.escenas.Normal()
    pilas.fondos.Galaxia()
    fin_de_Juego = False
    
    puntos = pilas.actores.Puntaje( x=-300, y=200, color= pilas.colores.blanco)
    fondo = pilas.fondos.Galaxia()    
    nave = pilas.actores.Nave( y= -200)
    nave.aprender('limitadoabordesdepantalla')
    
    disparo_de_nave = pilasengine.actores.Misil

    nave.aprender('disparar', municion = disparo_de_nave , angulo_salida_disparo = 90, frecuencia_de_disparo = 2)

    nave.aprender('puedeexplotar')

    nave.aprender('moverseconelteclado')

    def crear_ovni():
        enemigo1 = pilas.actores.Ovni( y = 200)
        enemigo1.radio_de_colision=25
        enemigo1.aprender('puedeexplotar')
        disparo_de_enemigo1 = pilasengine.actores.Bala
        enemigo1.aprender('disparar', control=None, municion = disparo_de_enemigo1 , angulo_salida_disparo = 270, frecuencia_de_disparo = 1, escala = 0.5)
    	
        def mover_ovni():	
            enemigo1.x = [0, -300, 300], 3
    
        pilas.tareas.agregar(0.5, mover_ovni)
        pilas.tareas.siempre(9.5, mover_ovni)
        
        def dispara():
            enemigo1.disparar()
            return True
        
        enemigo1.tarea_dispara = pilas.tareas.agregar(1, dispara)
        
    crear_ovni()
      
    #creacion del enemigo rocas
    def crear_enemigo():
        
        enemigo2 = pilas.actores.Piedra()
        enemigo2.aprender('puedeexplotarconhumo')
        enemigo2.x = pilas.azar(-200, 200)
        enemigo2.y = pilas.azar(-150, 150)
        enemigo2.velocidad = pilas.azar(10, 40) / 10.0
    	#enemigos.agregar(enemigo2)
    
        if fin_de_Juego:
            return False
        else: 
            return True
    pilas.tareas.siempre(1, crear_enemigo)
     
    def destruir(disparo, enem):
        disparo.eliminar()
        enem.eliminar()
    	#global puntos
        puntos.aumentar(5)
    
    def destruir_ovni(misil,ovni):
        crear_ovni()
        misil.eliminar()
        ovni.eliminar()
        ovni.tarea_dispara.eliminar()
        puntos.aumentar(50)
        
    def perder(nav, ene):
        nav.eliminar()
        #pilas.tareas.eliminar_todas()
        fin_de_Juego = True
        pilas.avisar("GAME OVER")
        salir1 = pilas.interfaz.Boton("Regresar al Menu")
        salir1.conectar(entrada)
        salir1.y = -175
    
        
    #Colisiones
    #pilas.escena_actual().colisiones.agregar(nave, enemigo1, nave.eliminar)
    pilas.colisiones.agregar('Nave', 'Piedra', perder)
    pilas.colisiones.agregar('Nave', 'Bala', perder)
    pilas.colisiones.agregar('Misil', 'Piedra', destruir)
    pilas.colisiones.agregar('Misil', 'Ovni', destruir_ovni)
    pilas.colisiones.agregar('Nave', 'Ovni', perder)
    

def instrucciones_juego():
	
    pilas.escenas.Normal()
    pilas.fondos.Galaxia()
    texto = pilas.actores.Texto("Instrucciones")
    texto.color = pilas.colores.Color(0, 0, 0)
    texto.y = 150
    texto.x = 0
    
    texto1 = pilas.actores.Texto("Esquiva los asteroides")
    texto1.color = pilas.colores.Color(0, 0, 0)
    texto.escala = 1.5
    texto1.escala = 0.5
    texto1.y = 65
    texto1.x = 40
    in1 = pilas.actores.Piedra()
    in1.escala = 1
    in1.x = -100
    in1.y = 65
    texto2 = pilas.actores.Texto("Destruye a los ovnis pero cuidado trataran de dispararte")
    texto2.color = pilas.colores.Color(0, 0, 0)
    texto2.escala = 0.5
    texto2.x = 20
    in2 = pilas.actores.Ovni()
    in2.escala = 1
    in2.x = -200
    in2.y = -5
    texto3 = pilas.actores.Texto("Este eres tu el capitan de la Flota Area Espacial Ecuatoriana")
    texto3.color = pilas.colores.Color(0, 0, 0)
    texto3.escala = 0.5
    texto3.x = 20
    texto3.y = -60
    in2 = pilas.actores.Nave()
    in2.escala = 1.5
    in2.x = -200
    in2.y = -60
    texto4 = pilas.actores.Texto("Muevete con las flechas direccionales y dispara tus torpedos de iones con la barra espaciadora")
    texto4.color = pilas.colores.Color(0, 0, 0)
    texto4.escala = 0.53
    texto4.x = 20
    texto4.y = -120
    
    salir1 = pilas.interfaz.Boton("Volver al Menu")
    salir1.conectar(entrada)
    salir1.y = -200

def opciones_juego():
    pilas.escenas.Normal()
    pilas.fondos.Galaxia()
    boton_musica = pilas.interfaz.Boton("Musica")
    boton_musica.x = 0
    boton_musica.y = 20    
    musica = pilas.sonidos.cargar('musica.ogg')	
    def reproducir_musica():
        musica.reproducir(repetir = True)

    boton_musica.conectar(reproducir_musica)
    
    boton_parar = pilas.interfaz.Boton("Detener Musica")
    boton_parar.x = 0
    boton_parar.y = -20
    
    def parar_musica():
        musica.detener()
        
    boton_parar.conectar(parar_musica)
    
    salir1 = pilas.interfaz.Boton("Regresar al Menu")
    salir1.conectar(entrada)
    salir1.y = -175   
 
def salida():
    pilas.escenas.Normal()
    pilas.fondos.Galaxia()
    textofinal = pilas.actores.Texto(" Creado por Jonathan Rosero")
    textofinal.color = pilas.colores.Color(255, 0, 0, 128)
    textofinal.x = 80
    textofinal.y = 100
    pilas.terminar()

entrada()
                        
pilas.ejecutar()