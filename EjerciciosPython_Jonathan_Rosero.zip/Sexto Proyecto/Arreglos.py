#las estructuras o arreglos empiezan a contar posiciones desde 0
#El tamaño del arreglo y la posición final tienen una relación de -1
#len c es para saber el tamaño de mi arreglo

c = [11,22,43,14]
suma = 0;

for i in range (len(c)):
    suma = suma + c[i]
    print (("posicion:%s - valor: %s")%(i, c[i]))

print (suma)
