Suma = 0
promedio = 0
respuestas = []

dias = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"]
#respuestas.append sirve para incluir nuevos elementos a la lista respuestas
for i in range(len(dias)):
    respuestas.append(input("Cuantos partidos jugados el dia {0}".format(dias[i])))

print("-------------------------------------------------")
#os ciclos for sirven para recorrer arreglos
for i in range(len(dias)):
    print("Partidos jugados el dia {0}: {1}".format(dias[i], respuestas[i]))

for i in range(len(respuestas)):
    suma += respuestas[i]

promedio = suma / len(respuestas)

print("El promedio de partidos jugados es {}".format(promedio))
