#este sera el programa principal que se ejecuta
#se crea un objeto de clase operacion
from Operacion import operacion as presenta

num = int(input("Ingrese el primer numero "))

num2 = int(input("Ingrese el segundo numero "))

op = int(input("1.Suma\n2.Resta\n3.Multiplicación\n4.División\n"))
#se llama a la clase impresion mediante el objeto presenta y se le envia los parametros necesarios
presenta.impresion(op, num, num2)
