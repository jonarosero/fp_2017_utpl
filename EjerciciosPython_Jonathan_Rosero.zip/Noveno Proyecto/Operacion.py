#esta clase sera la encargada de realizar todas las operaciones
class operacion :
        #las funciones suma, restar, mult, div reciben dos parametros o variables mientras que impresion recibe tres ninguna de ellas devuelve un valor
        def suma(valor1, valor2):
                suma = valor1 + valor2
                print(("La suma de %.d más %d es igual a: %d")%(valor1, valor2, suma))

        def restar(valor1, valor2):
                resta = valor1 - valor2
                print(("La resta de %.d menos %d es igual a: %d")%(valor1, valor2, resta))
                
        def mult(valor1, valor2):
                mult = valor1 * valor2
                print(("La multiplicacion de %.d por %d es igual a: %d")%(valor1, valor2, mult))

        def div(valor1, valor2):
                div = valor1 / valor2
                print(("La division de %.d entre %d es igual a: %d")%(valor1, valor2, div))

        def impresion (opcion, valor1, valor2):
                if (opcion == 1):
                        operacion.suma(valor1,valor2)
                elif (opcion == 2):
                        operacion.restar(valor1,valor2)
                elif (opcion == 3):
                        operacion.mult(valor1, valor2)
                else:
                        print("La opcion no es correcta")
