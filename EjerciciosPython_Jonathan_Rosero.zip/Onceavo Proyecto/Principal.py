#se importa la clase Estudiante
from Estudiante import Estudiante

#se crean dos objetos est y est2 de la clase Estudiante
est = Estudiante
est2 = Estudiante

suma_edades = 0
prom = 0
#se le asignan valores a los atributos de cada objeto
est.nombre = "Luis"
est2.nombre = "Maria"

est.edad = 18
est2.edad = 17

suma_edades = est.edad + est2.edad
prom =  suma_edades / 2

print(prom)
