class Estudiante:
#nombre y edad son atributos de la clase estudiante
    nombre = ""
    edad = 0
