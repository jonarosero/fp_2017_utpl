class OnceavoProyecto(object):
    """docstring for OnceavoProyecto."""
#init sirve para declarar variables o atributos de los objetos
    def __init__(self, arg):
        super(OnceavoProyecto, self).__init__()
        self.arg = arg
