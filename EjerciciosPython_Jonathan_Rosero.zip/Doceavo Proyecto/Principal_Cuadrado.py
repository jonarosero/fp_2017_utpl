from Cuadrado import Cuadrado

for i in range (5):
    #se crean 5 objetos de la clase cuadrado 
    c = Cuadrado
    lado = int(input("Ingrese lado del cuadrado: "))
    #se envia el valor del lado mediante la funcion agregar lado
    c.agregar_lado(lado)
    #se llama a las funciones calcular_area y perimetro
    area = c.calcular_area()
    perimetro = c.calcular_perimetro()
    print(("El cuadrado de lado: %d\n\tTiene un area de: %d\n\tTiene un perimetro de: %d")%(c.obtener_lado(),area,perimetro))
