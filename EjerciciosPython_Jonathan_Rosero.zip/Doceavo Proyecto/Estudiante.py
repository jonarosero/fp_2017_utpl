class Estudiante:
    nombre = ""
    edad = 0
#por cada atributo existen dos funciones uno para agregar valores y otro para obtener los valores de regreso
    def agregar_nombre(n):
        Estudiante.nombre = n

    def obtener_nombre():
        return Estudiante.nombre

    def agregar_edad(e):
        if(e < 18):
            Estudiante.edad = 18
        else:
            Estudiante.edad = e

    def obtener_edad():
        return Estudiante.edad
