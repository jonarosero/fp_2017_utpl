class Cuadrado:
    lado = 0
#por cada atributo existen dos funciones uno para agregar valores y otro para obtener los valores de regreso

    def agregar_lado(l):
        Cuadrado.lado = l

#las funciones de obtener y calcular no reciben valores y retornan valores de los atributos
    def obtener_lado():
        return Cuadrado.lado


    def calcular_area():
        area = Cuadrado.lado ** 2
        return area

    def calcular_perimetro():
        perimetro = Cuadrado.lado * 4
        return perimetro
