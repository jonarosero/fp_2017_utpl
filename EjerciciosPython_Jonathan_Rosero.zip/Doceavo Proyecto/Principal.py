#se importa la clase estudiante
from Estudiante import Estudiante
#se crean dos objetos
est = Estudiante
est2 = Estudiante
suma_edades = 0
prom = 0
#cada objeto envia un valor a su atributo mediante la funcion agregar
est.agregar_nombre("Luis")
est2.agregar_nombre("Maria")

est.agregar_edad(18)
est2.agregar_edad(17)
#como est y est2 son Estudiantes por lo tanto se debe llamar a los atributos enteros para sumar 
suma_edades = est.obtener_edad() + est2.obtener_edad()

prom = suma_edades / 2
#se imprime el valor de los objetos mediante la funcion obtener
print(est.obtener_nombre())
print(est.obtener_edad())
print(est2.obtener_edad())
print(suma_edades)
print(prom)
