class Estudiante:
    aux = ""
#valores de las propiedades sonn asignados al crear una instancia del objeto.
    def __init__(self, nombre, promedio):
        self.nombre = nombre
        self.promedio_final = promedio

    def obtener_promedio(self):
        return self.promedio_final
    
