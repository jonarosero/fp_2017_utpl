from Estudiante import Estudiante
 
suma  = 0
lista = []
#cada objeto envia su valor a la clase Estudiante
e = Estudiante("Rene", 10)
e2 = Estudiante("Luis", 4)
 
lista.append(e)
lista.append(e2)
 
for i in range(len(lista)):
    suma += lista[i].obtener_promedio()
print("Promedio: %.2f " %(suma / len(lista)))
