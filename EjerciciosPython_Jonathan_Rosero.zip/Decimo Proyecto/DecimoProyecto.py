#se crea un objeto t de la clase Trabajador 
from Trabajador import trabajador as t

nombre = input("Ingrese el Nombre del trabajador: ")
apellido = input("Ingrese el Apellido del trabajador: ")
cedula = input("Ingrese el Número de cedula del trabajador: ")
edad = int(input("Ingrese la Edad del trabajador: "))
sueldo_neto = float(input("Ingrese el Sueldo neto del trabajador; "))
#con el objeto t se llama a la clase trabajador a la funcion generar_recibo y se le envian los parametros necesarios
t.generar_recibo(nombre, apellido, cedula, edad, sueldo_neto)
