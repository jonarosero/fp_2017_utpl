#trabajador sera la clase que realizara todas las operaciones
class trabajador:
        
        def generar_recibo(n, ap, cd, edad, sueldo):
                descuento = trabajador.obtener_descuento(sueldo, edad)
                seguro = trabajador.obtener_seguro(sueldo)
                sueldo_final = sueldo + seguro - descuento

                print(("\nRecibo\nNombre: %s\tApellido: %s\nCedula: %s\nSueldo Final: %.2f")%(trabajador.obtener_mayusculas(n), ap, cd, sueldo_final))
#las funciones obtener_descuento obtener_seguro y obtener_mayusculas reciben y retornan valores
        def obtener_descuento(s, edad):
                d = 0;

                if (edad >= 50):
                        d = s * 0.05
                else:
                        d = s * 0.01
                return d
        
        def obtener_seguro(valor):
                s = valor * 0.15
                return s

        def obtener_mayusculas(valor2):
                valor_m = valor2.upper()
                return valor_m
