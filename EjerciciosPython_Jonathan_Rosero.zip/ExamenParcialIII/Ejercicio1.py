#[[] for i in nombres] es por cada uno de los nombres creando una instancia en la lista de una lista vacia que luego llenas
empleados = ["Vendedor 1", "Vendedor 2", "Vendedor 3", "Vendedor 4", "Vendedor 5"]
dias = ["Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado"]
sueldos = [[] for dia in dias]

valor = 0
k = 0
semanal = [0 for empleado in empleados]

total = 0
mayor = 0


for i in range(len(empleados)):
    print(empleados[i])
    sueldos.append([]);
    for j in range(len(dias)):
        ventas = int(input("Ingrese las ventas del dia {0}: ".format(dias[j])))

        if (ventas < 100):
            valor = 30
        elif (ventas > 1000):
            valor = 80
        else:
            valor = 50

        sueldos[j].append((ventas * 0.15) + valor)
        semanal[i] = semanal[i] + sueldos[j][i]

    semanal[i] = semanal[i] + (semanal[i] * 0.14)

    total = total + semanal[i]


for i in range(len(empleados)):

    print(empleados[i])

    for j in range(len(dias)):
        print("{0}: {1}".format(dias[j], sueldos[j][i]))

    print("El sueldo semanal es: {0}".format(semanal[i]))

print("Total a pagar a todos los empleados: {0}".format(total))

for i in range(len(empleados)):
    if(semanal[i] > mayor):
        mayor = semanal[i]
        k = i

print("El mejor empleado es {0} con un sueldo semanal de {1}".format(empleados[k], mayor))
