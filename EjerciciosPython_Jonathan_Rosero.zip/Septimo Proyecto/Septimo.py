#para determinar una lista se usa la estructura lista = []
arreglo = []
tam = 4
#el tamaño de la lista esta determinado por la variable 4
for fila in range(tam):
    #se incluye una lista dentro de la lista arreglo para crear arreglos bidimensionales
    arreglo.append([])
    for columna in range(tam):
        arreglo[fila].append(0)
        print(arreglo[fila][columna])
