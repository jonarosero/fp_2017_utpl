arreglo = [[7,7,8],[9,8,10],[10,10,3]]
promedios = []
estudiante = [["María","Loja"],["Luis","Quito"],["José","Cuenca"]]


print("REPORTE: ")
for fila in range(len(arreglo)):
    prom = 0
    for columna in range(len(arreglo[fila])):
        prom = prom + arreglo[fila][columna]
    promedios.append(prom / len(arreglo[fila]))

    print("Nombre: {0}\nCiudad: {1}\nPromedio:{2}".format(estudiante[fila][0], estudiante[fila][1], promedios[fila]))
    print("\n")
