arreglo = [[7,7,8],[9,8,10],[10,10,3]]
j = 0
suma = 0

opc = int(input("Op 1 Impares diagonal\nOp 2 Impares bajo diagonal\nOp 3 Impares sobre diagonal\n "))
for fila in range(len(arreglo)):
    for columna in range(len(arreglo[fila])):
        print(arreglo[fila][columna])
print("\n")


print("Numeros Impares")
if (opc == 1):
    for fila in range(len(arreglo)):
        if(arreglo[fila][j] % 2 != 0):
            print(arreglo[fila][j])
        j += 1;
elif (opc == 2):
    for fila in range(len(arreglo)):
        for columna in range(len(arreglo[fila])):
            if(fila > columna):
                if (arreglo[fila][columna] % 2 != 0):
                    print(arreglo[fila][j])
elif (opc == 3):
    for fila in range(len(arreglo)):
        for columna in range(len(arreglo[fila])):
            if(fila < columna):
                if (arreglo[fila][columna] % 2 != 0):
                    print(arreglo[fila][j])
