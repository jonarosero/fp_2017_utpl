arreglo = [[7,7,8],[9,8,10],[10,10,3]]
j = 0
suma = 0


print("REPORTE: ")
for fila in range(len(arreglo)):
    for columna in range(len(arreglo[fila])):
        print(arreglo[fila][columna])
    print("\n")

for fila in range(len(arreglo)):
    suma += arreglo[fila][j]
    j += 1;
print("Diagonal suma: {0}".format(suma))
