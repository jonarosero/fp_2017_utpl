arreglo = []
tam = 4
#el primer for recorre las filas del arreglo y el segundo for recorre las columnas
for fila in range(tam):
    arreglo.append([])
    for columna in range(tam):
        arreglo[fila].append(0)
        print(arreglo[fila][columna])
