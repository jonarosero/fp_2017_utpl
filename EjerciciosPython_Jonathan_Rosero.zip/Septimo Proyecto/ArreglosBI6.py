arreglo = [[7,7,8],[9,8,10],[10,10,3]]
suma = 0

for fila in range(len(arreglo)):
    for columna in range(len(arreglo[fila])):
        print(arreglo[fila][columna])
        if (fila > columna):
            suma += arreglo[fila][columna]
    print("\n")

print("Diagonal suma: {0}".format(suma))
