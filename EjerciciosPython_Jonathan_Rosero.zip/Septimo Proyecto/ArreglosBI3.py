arreglo = [[7,7,8],[9,8,10],[10,10,3]]

for fila in range(len(arreglo)):
    prom = 0
    #El promedio es un acumulador que suma los datos del arreglo bidimensional
    for columna in range(len(arreglo[fila])):
        prom = prom + arreglo[fila][columna]
        print(arreglo[fila][columna])
    print("Promedio:{0}".format(prom))
