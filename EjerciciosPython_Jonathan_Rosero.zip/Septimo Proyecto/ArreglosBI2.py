arreglo = [[1,2,3],[11,22,33]]
#se puede inicializar los valores de un arreglo bidimensional, creando una lista dentro de otra lista
for fila in range(len(arreglo)):
    for columna in range(len(arreglo[fila])):
        print(arreglo[fila][columna])
